var socket = io.connect('http://localhost');

function toggle(){
  $("#disconected").toggleClass("hide");
  $("#connected").toggleClass("hide");
}
socket.on('connected',function () {
   console.log('Conectado !!!');
   toggle();
});

$('#button').click(function() {
   socket.emit('click');
})

socket.on('otherClick',function() {
   console.log('clicks'+clicks);
   $('h2').replaceWith('<h2>Has pulsado '+clicks+' veces!!!');
})

socket.on('disconected',function () {
   console.log('Desconectado');
   toggle();
});



// var socket = io.connect('http://localhost:3000');
//
// socket.on('connected', function () {
//       console.log('Conectado!');
//       toggle();
//     });

// document.addEventListener('DOMContentLoad',function() {
//   socket.emit('start',function(a) {
//     a.forEach(function(val,key) {
//       $('#info>tbody').append(val);
//     });
//   });
// });
